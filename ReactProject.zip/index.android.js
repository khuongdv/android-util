'use strict';
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 */

import React, {
  AppRegistry,
  StyleSheet,
  Component,
  Text,
  View,
  Navigator,
  TouchableOpacity,
  BackAndroid,
} 
from 'react-native';
var _navigator;

import Dashboard from './App/Views/Dashboard/index.android.js';
import YoutubeChannelList from './App/Views/YoutubeChannelList/index.android.js';

class ReactProject extends React.Component {
	render(){
		return (
			<Navigator 
				initialRoute={{id: "first"}}
				renderScene={this.renderScene}
				tintColor='#FF6600'
				configScene={(route) => {
				  if (route.sceneConfig) {
					return route.sceneConfig;
				  }
				  return Navigator.SceneConfigs.FadeAndroid;
				}}		
			/>
		);
	}
	
	renderScene(route, navigator){
		var id = route.id;
		_navigator = navigator;
		if(id === "first"){
			return (
				<Dashboard navigator={navigator}/>
			);
		}
		if(id === "numberlist"){
			return (
				<YoutubeChannelList navigator={navigator}/>
			);
		}
		if(id === "Post"){
        return (<Post navigator={navigator}
                      title={route.title}
                      post={route.post}/>);
		}
      if(id === "Web"){
          return (
            <View style={{flex: 1}}>
                <ToolbarAndroid style={styles.toolbar}
                                title={route.title}
                                navIcon={{uri: "ic_arrow_back_white_24dp", isStatic: true}}
                                onIconClicked={navigator.pop}
                                titleColor={'#FFFFFF'}/>
                <WebView source={{uri: route.url}}
                         javaScriptEnabled={true}/>
            </View>
          );
		}
	}

};
BackAndroid.addEventListener('hardwareBackPress', () => {
  if (_navigator.getCurrentRoutes().length === 1  ) {
     return false;
  }
  _navigator.pop();
  return true;
});


AppRegistry.registerComponent('ReactProject', () => ReactProject);
