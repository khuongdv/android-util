'use strict';
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 */

import React, {
  AppRegistry,
  StyleSheet,
  Component,
  Text,
  View,
  Navigator,
  TouchableOpacity,
  BackAndroid,
} 
from 'react-native';
var _navigator;

import Dashboard from './App/Views/Dashboard/index.android.js';
import YoutubeChannelList from './App/Views/YoutubeChannelList/index.android.js';
import WebsiteList from './App/Views/WebsiteList.js';

class ReactProject extends React.Component {
	render(){
		return (
			<Navigator 
				initialRoute={{id: "first"}}
				renderScene={this.renderScene}
				tintColor='#FF6600'
				configScene={(route) => {
				  if (route.sceneConfig) {
					return route.sceneConfig;
				  }
				  return Navigator.SceneConfigs.VerticalUpSwipeJump;
				}}		
			/>
		);
	}
	
	renderScene(route, navigator){
		var id = route.id;
		_navigator = navigator;
		if(id === "first"){
			return (
				<Dashboard navigator={navigator}/>
			);
		}
		if(id === "numberlist"){
			return (
				<YoutubeChannelList navigator={navigator}/>
			);
		}
		if(id === "websitelist"){
        return (<WebsiteList navigator={navigator}
                      />);
		}
      if(id === "ebooks"){
          return (
            <View style={{flex: 1}}>
                <Text>Ebooks List</Text>
            </View>
          );
		}
	}

};
BackAndroid.addEventListener('hardwareBackPress', () => {
  if (_navigator.getCurrentRoutes().length === 1  ) {
     return false;
  }
  _navigator.pop();
  return true;
});


AppRegistry.registerComponent('ReactProject', () => ReactProject);
