
'use strict';

import Realm from 'realm';

class Todo { }
Todo.schema = {
    name: 'Todo',
    properties: {        
        text: Realm.Types.STRING,
    },
};
export default new Realm({ schema: [Todo] });