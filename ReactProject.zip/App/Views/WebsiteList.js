'use strict';
const MK = require('react-native-material-kit');
const {
    MKButton, MKTouchable, MKSpinner, TickView,
    MKColor
} = MK;

import React from 'react-native';
import RealmUtil from '../DBUtils/RealmUtil';
var {Text, TextInput, DatePickerAndroid, Alert,
    TouchableWithoutFeedback,
    View, StyleSheet, TouchableHighlight, Image} = React;

export default class WebsiteList extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            presetDate: new Date(2020, 4, 5),
            allDate: new Date(2020, 4, 5),
            simpleText: 'pick a date',
            minText: 'pick a date, no earlier than today',
            maxText: 'pick a date, no later than today',
            presetText: 'pick a date, preset to 2020/5/5',
            allText: 'pick a date between 2020/5/1 and 2020/5/10',
        };
    }
    //-----------------------
    showScreen(scene) {
        this.props.navigator.push({ id: scene });
    }
    render() {
        var text;
        var ColoredRaisedButton = MKButton.coloredButton()
            .withText('Luu lai nhe')
            .withOnPress(() => {
                RealmUtil.write(() => {
                    let todoList = RealmUtil.objects('Todo');
                    RealmUtil.delete(todoList);
                    RealmUtil.create("Todo", { text: 'hello from the other side' + new Date() });
                });
                let todoLists = RealmUtil.objects('Todo');
                console.log("--- Get from DB---");
                Alert.alert(
                    'Alert Title',
                    JSON.stringify(todoLists, null, 2),
                    [                        
                        { text: 'OK', onPress: () => console.log('OK Pressed') },
                    ]
                )
            })
            .build();
        return (
            <View>
                <TextInput
                    style={{ height: 40, borderColor: 'gray', borderWidth: 1, width: 200 }}
                    autoCorrect={true}
                    placeholder="This has autoCorrect"
                    value={text}
                    />
                <ColoredRaisedButton/>

            </View>
        );
    }

    //----------------------
    async showPicker(stateKey, options) {
        try {
            var newState = {};
            const {action, year, month, day} = await DatePickerAndroid.open(options);
            if (action === DatePickerAndroid.dismissedAction) {
                newState[stateKey + 'Text'] = 'dismissed';
            } else {
                var date = new Date(year, month, day);
                newState[stateKey + 'Text'] = date.toLocaleDateString();
                newState[stateKey + 'Date'] = date;
            }
            this.setState(newState);
        } catch ({code, message}) {
            console.warn(`Error in example '${stateKey}': `, message);
        }
    }
    //--------------------------
}
var styles = StyleSheet.create(
    {

    }
);