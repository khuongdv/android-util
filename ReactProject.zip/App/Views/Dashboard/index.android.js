'use strict';

var React = require('react-native');
import Button from 'apsl-react-native-button';
var {Text,View,StyleSheet,TouchableHighlight,Image} = React;

class Dashboard extends React.Component {
    constructor(props){
        super(props);
    }
    _onPressButton(_screen){
        this.props.navigator.push({id:"numberlist"});        
    }
    render() {
        return (
            <View>
                <View style={styles.container}>
                    <Image
                        style={{ width: 160, height: 160, paddingTop: 40 }}
                        source={{ uri: "https://scontent-hkg3-1.xx.fbcdn.net/v/t1.0-1/c0.35.160.160/p160x160/12246842_956208817758740_6751273305839582112_n.jpg" }}
                        />
                    <Text>This app's purpose is to give you list of resources for learning English. Don't mind to send feedback
                    to me if any.</Text>
                    <Text>========= App's Author Info =========</Text>                    
                    <Text>✔ @Name: Khuong Dao.</Text>
                    <Text>✔ @Email: minh.khuong1306 @gmail.com</Text>
                    <Text>✔ @Skype: khuongdv.ptit</Text>
                    <Text>✔ @Github: khuongdv</Text>                
                </View>
                <View style={{alignItems: "center"}}>
                    <React.TouchableOpacity onPress={()=> this._onPressButton("youtube")}
                        style={styles.row_container}
                        >                        
                        <Text style={styles.row_text}>List Youtube Channels</Text>
                    </React.TouchableOpacity>
                                        
                    <React.TouchableOpacity onPress={()=>this._onPressButton("websites")}
                        style={styles.row_container}
                        >                        
                        <Text style={styles.row_text}>List Websites</Text>
                    </React.TouchableOpacity>
                    
                    <React.TouchableOpacity onPress={()=>this._onPressButton("ebooks")}
                        style={styles.row_container}
                        >                        
                        <Text style={styles.row_text}>List Ebooks</Text>
                    </React.TouchableOpacity>
                </View>
            </View>
        );
    }
}

var styles = StyleSheet.create({
    container: {
        alignItems: "center",
        borderRadius: 4,
        borderWidth: 0.5,
        borderColor: '#d6d7da',
    },
    row_container: {
    backgroundColor: 'rgba(0, 0, 0, 0.1)',
        flex: 1,
        width: 200,
        borderColor: '#dd55ff',
        borderWidth: 1,
        borderRadius: 5,
        padding: 5,
        margin: 3,
    },
    row_text: {
        flex: 1,
        fontSize: 18,
        alignSelf: 'center',
    },
});
export default Dashboard;