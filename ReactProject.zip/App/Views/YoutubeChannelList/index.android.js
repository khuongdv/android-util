'use strict';

var React = require('react-native');
import Button from 'apsl-react-native-button';
var {Text,View,StyleSheet,TouchableHighlight,Image} = React;
var GiftedListView = require('react-native-gifted-listview');

class YoutubeChannelList extends React.Component {
    constructor(props){
        super(props);
    }
    
    /**
     * When a row is touched
     * @param {object} rowData Row data
     */
    _onPress(rowData) {
        
    }
    /**
     * Render a row
     */
    _renderRowView(rowData){
        return (
            <TouchableHighlight
                style={styles.row}
                underlayColor='#c8c7cc'
                onPress={() => this._onPress(rowData)}
            >  
                <Text>{rowData}</Text>
            </TouchableHighlight> 
        );
    }
    /**
     * Will be called when refreshing
     */
    _onFetch(page = 1, callback, options){
        var rows = ["Songokute", "Ngoc"];
        callback(rows);
    }
    
    render() {
        return (
            <View style={styles.container}>
                 <View style={styles.navBar} />
                 <GiftedListView
                    rowView={this._renderRowView}
                    onFetch={this._onFetch}
                    firstLoader={true} // display a loader for the first fetching
                    pagination={true} // enable infinite scrolling using touch to load more
                    refreshable={true} // enable pull-to-refresh for iOS and touch-to-refresh for Android
                    withSections={false} // enable sections
                    customStyles={{
                        paginationView: {
                        backgroundColor: '#eee',
                        },
                    }}

                    refreshableTintColor="blue"
                 />
            </View>            
        );
    }
}

var styles = StyleSheet.create({
    container: {
        alignItems: "center",
        borderRadius: 4,
        borderWidth: 0.5,
        borderColor: '#d6d7da',
    },
    navBar: {
        height: 64,
        backgroundColor: '#CCC'
    },
    row_container: {
        backgroundColor: 'rgba(0, 0, 0, 0.1)',
        flex: 1,
        width: 200,
        borderColor: '#dd55ff',
        borderWidth: 1,
        borderRadius: 5,
        padding: 5,
        margin: 3,
    },
    row_text: {
        flex: 1,
        fontSize: 18,
        alignSelf: 'center',
    },
});
export default YoutubeChannelList;