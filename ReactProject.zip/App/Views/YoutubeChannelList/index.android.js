'use strict';

var DOMParser = require('xmldom').DOMParser;


var React = require('react-native');
var Dimensions = require("Dimensions");
var {Text, View, StyleSheet, TouchableHighlight, Image, TouchableOpacity} = React;
var THIS;
class YoutubeChannelList extends React.Component {

    constructor(props) {
        super(props);
        THIS = this;
        this.state = { today: new Date().toDateString() };
        // request('http://xskt.com.vn/rss-feed/mien-bac-xsmb.rss', function (error, response, body) {
        //     if (!error && response.statusCode == 200) {
        //         parseString(body, function (err, result) {
        //             THIS.state = { result: result }
        //         });
        //     }
        // });
        fetch('http://xskt.com.vn/rss-feed/mien-bac-xsmb.rss', {
            method: 'GET',
            headers: {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Content-Type': 'text/xml;charset=UTF-8',
            }
        }).then(function (response) {
            //var doc = new DOMParser().parseFromString(s, 'text/xml');
            // THIS.state.result = response;
            var JSONResponse = response._bodyInit;
            var doc = new DOMParser().parseFromString(JSONResponse, 'text/xml');
            var firstItem = doc.getElementsByTagName('item')[0];
            var title = firstItem.getElementsByTagName('title')[0];

            var description = firstItem.getElementsByTagName("description")[0];
            THIS.setState({ title: title.textContent, giaithuong: description.textContent });
        });
    }
    render() {

        return (
            <View style={styles.container}>
                <View style={styles.headerTitle}>
                    <Text>{this.state.title}</Text>
                </View>
                <View style={styles.headerTitle}>
                    <Text>Cơ cấu giải</Text>
                </View>
                <View style={styles.prizeBlock}>
                    <Text style={styles.title}>{this.state.giaithuong}</Text>
                </View>
                <View>
                    <TouchableOpacity onPress={this._onPressButton}
                        style={{backgroundColor: 'rgba(0, 0, 0, 0.1)',
                                flex: 1,
                                width: 200,
                                borderColor: '#dd55ff',
                                borderWidth: 1,
                                borderRadius: 5,
                                padding: 5,
                                margin: 3}}
                        >
                        <Text style={{flex: 1,
                                        fontSize: 18,
                                        alignSelf: 'center',}}>
                              &larr; Xem ngày hôm qua
                        </Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }
}
var windowSize = Dimensions.get('window');
const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: 'transparent'
    },
    headerTitle: {
        justifyContent: "center",
        alignItems: 'center',
        backgroundColor: 'transparent'
    },
    prizeBlock: {
        justifyContent: "center",
        alignItems: 'center',
        flexDirection: 'row'
    },
    giaiDBTitle: {
        justifyContent: "center",
        alignItems: 'center',
        backgroundColor: 'transparent',
        flex: 1
    },
    giaiDBValue: {
        justifyContent: "center",
        alignItems: 'center',
        backgroundColor: 'transparent',
        color: 'red',
        flex: 1
    }
    ,
});

export default YoutubeChannelList;